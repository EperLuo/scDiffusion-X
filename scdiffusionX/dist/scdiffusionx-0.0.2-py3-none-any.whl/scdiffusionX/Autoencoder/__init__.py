"""Top-level package for scgm."""

__author__ = "Till Richter"
__email__ = "till-richter@gmx.de"
__version__ = "0.1.0"
