"""Celldreamer - generative modeling of single-cell data."""

__version__ = '0.1.0'
__author__ = 'Till Richter <till.richter@helmholtz-muenchen.de>'
__all__ = []
